"""
Test suite for NyayaMithra.
"""
